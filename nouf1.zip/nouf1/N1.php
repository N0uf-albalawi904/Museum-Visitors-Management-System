<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Museum";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$message = ""; 


if (isset($_POST['add'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $password = $_POST['password'];

 
    $imageName = $_FILES['visitorImage']['name'];
    $imageTempName = $_FILES['visitorImage']['tmp_name'];
    $uploadDir = "up/";
    $imagePath = $uploadDir . basename($imageName);

    if (move_uploaded_file($imageTempName, $imagePath)) {
        $sql = "INSERT INTO Visitors (VisitorFname, VisitorLname, VisitorImage, VisitorAge, VisitorPassword, VisitorEmail) 
                VALUES ('$fname', '$lname', '$imagePath', '$age', '$password', '$email')";
        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>Visitor added successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Error inserting data: " . mysqli_error($conn) . "</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>Failed to upload the image!</div>";
    }
}


if (isset($_POST['search'])) {
    $searchId = $_POST['visitor_id'];
    $sql = "SELECT * FROM Visitors WHERE VisitorID = '$searchId'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $visitor = mysqli_fetch_assoc($result);
        $message = "<div class='alert alert-success'>
                        <p><strong>ID:</strong> {$visitor['VisitorID']}</p>
                        <p><strong>First Name:</strong> {$visitor['VisitorFname']}</p>
                        <p><strong>Last Name:</strong> {$visitor['VisitorLname']}</p>
                        <p><strong>Age:</strong> {$visitor['VisitorAge']}</p>
                        <p><strong>Email:</strong> {$visitor['VisitorEmail']}</p>
                        <img src='{$visitor['VisitorImage']}' alt='Visitor Image' width='150'>
                    </div>";
    } else {
        $message = "<div class='alert alert-danger'>No visitor found with ID $searchId!</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add or Search Visitor</title>
    <link rel="stylesheet" href="N3.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Add New Visitor</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="fname" placeholder="First Name" class="form-control mb-2" required>
        <input type="text" name="lname" placeholder="Last Name" class="form-control mb-2" required>
        <input type="number" name="age" placeholder="Age" class="form-control mb-2" required>
        <input type="email" name="email" placeholder="Email" class="form-control mb-2" required>
        <input type="password" name="password" placeholder="Password" class="form-control mb-2" required>
        <input type="file" name="visitorImage" class="form-control mb-2" required><br>
        <button type="submit" name="add" class="btn">Add Visitor</button>
    </form>

    <h2 class="mt-5 mb-4">Search Visitor by ID</h2>
    <form method="POST">
        <input type="number" name="visitor_id" placeholder="Enter Visitor ID" class="form-control mb-2" required>
        <button type="submit" name="search" class="btn">Search</button>
    </form>

    <a href="N2.php">View All Visitors</a>
    <?php echo $message; ?>
</div>
</body>
</html>
