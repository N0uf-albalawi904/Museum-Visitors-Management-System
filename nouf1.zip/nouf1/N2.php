<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Museum";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Failed to connect to the database: " . mysqli_connect_error());
}


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM Visitors WHERE VisitorID = $id";
    mysqli_query($conn, $sql);
  
}


$edit_row = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM Visitors WHERE VisitorID = $id");
    if ($result && mysqli_num_rows($result) > 0) {
        $edit_row = mysqli_fetch_assoc($result);
    }
}


if (isset($_POST['update'])) {
    $id12 = $_POST['id'];
    $fname12 = $_POST['fname'];
    $lname12 = $_POST['lname'];
    $age12 = $_POST['age'];
    $email12 = $_POST['email'];

    $sql = "UPDATE Visitors SET VisitorFname='$fname12', VisitorLname='$lname12', VisitorAge='$age12', VisitorEmail='$email12' WHERE VisitorID=$id12";
    if (mysqli_query($conn, $sql)) {
        $message12 = "<div class='alert alert-success'>Visitor details updated successfully!</div>";
    } else {
        $message12 = "<div class='alert alert-danger'>Update failed: " . mysqli_error($conn) . "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Display Visitors</title>
    <link rel="stylesheet" href="N3.css">
</head>
<body>
<div class="container">
    <h2>Display All Visitors</h2>

    <?php if (isset($message12)) echo $message12; ?>
  
    <table>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Age</th>
            <th>Email</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM Visitors");
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['VisitorID']; ?></td>
                <td><?php echo $row['VisitorFname']; ?></td>
                <td><?php echo $row['VisitorLname']; ?></td>
                <td><?php echo $row['VisitorAge']; ?></td>
                <td><?php echo $row['VisitorEmail']; ?></td>
                <td><img src="<?php echo $row['VisitorImage']; ?>" style="width: 100px;"></td>
                <td>
                    <a href="N2.php?delete=<?php echo $row['VisitorID']; ?>">Delete Visitor</a> |
                    <a href="N2.php?edit=<?php echo $row['VisitorID']; ?>">Edit Visitor</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <!-- Edit Form -->
    <?php if ($edit_row): ?>
        <div class="edit-form">
            <h3>Edit Visitor Details</h3>
            <form method="POST">
                <input type="hidden" name="id" value="<?php echo $edit_row['VisitorID']; ?>">
                <input type="text" name="fname" value="<?php echo $edit_row['VisitorFname']; ?>" placeholder="First Name" required><br>
                <input type="text" name="lname" value="<?php echo $edit_row['VisitorLname']; ?>" placeholder="Last Name" required><br>
                <input type="number" name="age" value="<?php echo $edit_row['VisitorAge']; ?>" placeholder="Age" required><br>
                <input type="email" name="email" value="<?php echo $edit_row['VisitorEmail']; ?>" placeholder="Email" required><br>
                <button type="submit" name="update">Save </button>
            </form>
        </div>
    <?php endif; ?>
    <a href="N1.php">Add New Visitor</a>
</div>
</body>
</html>
